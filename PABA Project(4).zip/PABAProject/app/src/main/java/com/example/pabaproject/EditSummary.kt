package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class EditSummary : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var etSummary : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_summary)

        db = FirebaseFirestore.getInstance()

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.ivEditSumBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }


        etSummary = findViewById(R.id.etEditSumSummary)

        //filling informations
        updateInfo(email)


        //save
        val btnSave = findViewById<Button>(R.id.btnEditSumSave)
        btnSave.setOnClickListener {
            val collection = db.collection("tbProfileDetail")
            val query = collection.whereEqualTo("email", email)
            query.get()
                .addOnSuccessListener { documents ->
                    if (documents.size() > 0) {
                        val document = documents.first()
                        val documentReference = document.reference

                        documentReference.update("summary", etSummary.text.toString())
                    }
                    updateInfo(email)
                    Toast.makeText(applicationContext, "Change Saved!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                }
        }
    }

    private fun updateInfo(email : String) {
        val collection = db.collection("tbProfileDetail")
        val query = collection.whereEqualTo("email", email)
        query.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    etSummary.hint = document.data["summary"].toString()
                    etSummary.setText(document.data["summary"].toString())
                }
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Error getting documents: ", exception)
            }
    }
}