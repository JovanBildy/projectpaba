package com.example.pabaproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

//     Kelompok Project :
//     Reynaldo Halim, Jovan Bildy, Patrick Nathanael
//    C14200130, C14200129

    private lateinit var db : FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = FirebaseFirestore.getInstance()

        val etLoginEmail = findViewById<EditText>(R.id.etLoginEmail)
        val etLoginPassword = findViewById<EditText>(R.id.etLoginPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvGoToRegister = findViewById<TextView>(R.id.tvGoToRegister)

        tvGoToRegister.setOnClickListener{
            startActivity(Intent(this@MainActivity, Register::class.java))
        }

        btnLogin.setOnClickListener{
            if (etLoginEmail.text.toString() != "" && etLoginPassword.text.toString() != "") {
                login(etLoginEmail.text.toString(), etLoginPassword.text.toString())
            }
        }

//        val btnGo = findViewById<Button>(R.id.go)
//        btnGo.setOnClickListener {
//            startActivity(
//                Intent(
//                    applicationContext, Profile::class.java
//                )
//            .putExtra("idJob", "urg3AMqWBAHyWzCKwfLr")
//                    .putExt

    }

    private fun login(email: String, pass: String) {
        var savedPass = ""
        var found = false

        db.collection("tbUser")
            .whereEqualTo("email", email)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    found = true
                    savedPass = "${document.data["password"]}"
                }
                if (found) {
                    if (pass == savedPass) {
                        startActivity(
                            Intent(
                                applicationContext, CountrySelection::class.java)
                                .putExtra("email", email)
                        )
                    }
                    else
                        Toast.makeText(applicationContext, "Password Salah", Toast.LENGTH_LONG).show()
                }
                else
                    Toast.makeText(applicationContext, "Email belum terdaftar", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { exception ->
                Log.w("pass error", "Error getting documents: ", exception)
            }

    }
}