package com.example.pabaproject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdapterJobCard (
    private val listJob: ArrayList<Job>
) : RecyclerView.Adapter<AdapterJobCard.ListViewHolder> (){

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var ivLogo = itemView.findViewById<ImageView>(R.id.ivHomeJobCardLogo)!!
        var tvPosisi = itemView.findViewById<TextView>(R.id.tvHomeJobCardPosisi)!!
        var tvPerusahaan = itemView.findViewById<TextView>(R.id.tvHomeJobCardPerusahaan)!!
        var tvLokasi = itemView.findViewById<TextView>(R.id.tvJobHomeCardLokasi)!!
        var tvGaji = itemView.findViewById<TextView>(R.id.tvJobHomeCardGaji)!!
    }

    private lateinit var onItemClickCallback : OnItemClickCallback

    interface OnItemClickCallback {
        fun onItemClicked(data: Job)
        fun delData(pos : Int)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.job_home_card, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val job = listJob[position]

//        try {
//            holder.ivLogo.setImageURI(job.Logo.toUri())
//        }
//        catch (ex : Exception){
//            System.out.println(ex)
//        }

        holder.tvPosisi.text = job.Posisi
        holder.tvPerusahaan.text = job.Perusahaan
        holder.tvLokasi.text = job.Lokasi
        holder.tvGaji.text = job.Gaji

        holder.ivLogo.setOnClickListener {
            onItemClickCallback.onItemClicked(listJob[position])
        }
    }

    override fun getItemCount(): Int {
        return listJob.size
    }
}


