package com.example.pabaproject

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class Home : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private var arJob = arrayListOf<Job>()
    private var arRecommendation = arrayListOf<Job>()

    private lateinit var rvJob : RecyclerView
    private lateinit var rvRecommendation : RecyclerView
    private lateinit var ivProfilePict : ImageView
    private lateinit var tvNama  : TextView

    private lateinit var email : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        db = FirebaseFirestore.getInstance()
        rvJob = findViewById(R.id.rvJob)
        rvRecommendation = findViewById(R.id.rvRecommendation)

        //email
        email = intent.getStringExtra("email").toString()

        //fill info
        ivProfilePict = findViewById(R.id.profile)
        tvNama = findViewById(R.id.teksnama)

        val collection = db.collection("tbProfileDetail")
        val query = collection.whereEqualTo("email", email)
        query.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
//                    ivProfilePict.setImageURI(document.data["profilePicUrl"].toString().toUri())
                    tvNama.text = document.data["fullName"].toString()
                }
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents: ", exception)
            }

        //profile
        ivProfilePict.setOnClickListener{
            startActivity(
                Intent(
                applicationContext, Profile::class.java)
                .putExtra("email", email)
            )
        }

        //navbar
        val navbarProfile = findViewById<ImageView>(R.id.imageView15)
        navbarProfile.setOnClickListener {
            startActivity(
                Intent(
                    applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }

        val navbarSaved = findViewById<ImageView>(R.id.imageView14)
        navbarSaved.setOnClickListener {
            startActivity(
                Intent(
                    applicationContext, SavedJobs::class.java)
                    .putExtra("email", email)
            )
        }


        buildRecommendation()
        importJobsFromDb()
    }

    private fun showRecommendation(){
        val adapterRecommendation = AdapterJobCard(arRecommendation)

        rvRecommendation.layoutManager = LinearLayoutManager(this)
        rvRecommendation.adapter = adapterRecommendation

        adapterRecommendation.setOnItemClickCallback(object : AdapterJobCard.OnItemClickCallback {
            override fun onItemClicked(job: Job) {
                val intent = Intent(applicationContext, JobDetail::class.java)
                intent.putExtra("idJob", job.Id)
                intent.putExtra("email", email)
                startActivity(intent)
            }

            override fun delData(pos: Int) {
            }
        })
    }

    private fun importJobsFromDb(){
        arJob.clear()
        db.collection("tbJob").limit(6).get()
            .addOnSuccessListener {
                    documents ->
                for (document in documents) {
                    val id = document.data?.get("id").toString()
                    val logo = document.data?.get("logo").toString()
                    val posisi = document.data?.get("posisi").toString()
                    val perusahaan = document.data?.get("perusahaan").toString()
                    val lokasi = document.data?.get("lokasi").toString()
                    val gaji = document.data?.get("gaji").toString()
                    val deskripsi = document.data?.get("deskripsi").toString()
                    val minQ = document.data?.get("minimumQualification").toString()
                    val kategori = document.data?.get("kategori").toString()

                    val job = Job(
                        id,
                        perusahaan,
                        lokasi,
                        posisi,
                        logo,
                        gaji,
                        deskripsi,
                        minQ,
                        kategori
                    )
                    arJob.add(job)
                }
                showJobs()
            }
    }

    private fun showJobs() {
        val adapterJob = AdapterJobCard(arJob)

        rvJob.layoutManager = LinearLayoutManager(this)
        rvJob.adapter = adapterJob

        adapterJob.setOnItemClickCallback(object : AdapterJobCard.OnItemClickCallback {
            override fun onItemClicked(job: Job) {
                Toast.makeText(applicationContext, job.Perusahaan, Toast.LENGTH_LONG).show()
                val intent = Intent(applicationContext, JobDetail::class.java)
                intent.putExtra("idJob", job.Id)
                intent.putExtra("email", email)
                startActivity(intent)
            }

            override fun delData(pos: Int) {
            }
        })
    }

    private fun buildRecommendation() {
        arRecommendation.clear()

        db.collection("tbSkill").whereEqualTo("email", email).limit(3).get()
            .addOnSuccessListener { skills ->
            for (skill in skills) {
                db.collection("tbJob").whereEqualTo("kategori", skill["skill"].toString()).limit(1).get()
                    .addOnSuccessListener { jobs ->
                        for (document in jobs) {
                            val id = document.data?.get("id").toString()
                            val logo = document.data?.get("logo").toString()
                            val posisi = document.data?.get("posisi").toString()
                            val perusahaan = document.data?.get("perusahaan").toString()
                            val lokasi = document.data?.get("lokasi").toString()
                            val gaji = document.data?.get("gaji").toString()
                            val deskripsi = document.data?.get("deskripsi").toString()
                            val minQ = document.data?.get("minimumQualification").toString()
                            val kategori = document.data?.get("kategori").toString()

                            val job = Job(
                                id,
                                perusahaan,
                                lokasi,
                                posisi,
                                logo,
                                gaji,
                                deskripsi,
                                minQ,
                                kategori
                            )
                            arRecommendation.add(job)
                        }
                        showRecommendation()
                    }
            }
        }
    }
}