package com.example.pabaproject

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class JobInput : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private lateinit var  etPosisi : EditText
    private lateinit var  etPerusahaan : EditText
    private lateinit var  etLokasi : EditText
    private lateinit var  etGaji : EditText
    private lateinit var  etDeskripsi : EditText
    private lateinit var  etMinQ : EditText
    private lateinit var ivJobLogo : ImageView
    private lateinit var imgUrl : String
    private lateinit var  spinnerJInputCategory : Spinner
    private val galleryReqCode = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_input)

        db = FirebaseFirestore.getInstance()

        //logo
        ivJobLogo = findViewById(R.id.ivJobLogo)
        imgUrl = ""
        val btnSelectLogo = findViewById<Button>(R.id.btnSelectLogo)

        btnSelectLogo.setOnClickListener{
            val iGallery = Intent(Intent.ACTION_PICK)
            iGallery.data = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            startActivityForResult(iGallery, galleryReqCode)
        }
        //end of logo


        //spinner
        spinnerJInputCategory = findViewById(R.id.spinnerJInputCategory)
        val arrExpertise = arrayOf(
            "Accounting and Finance", "Architecture and Engineering", "Information Technology and Software",
            "Management and Consultancy", "Media, Design, and Creatives", "Sales and Marketing",
            "Writing and Content"
        )

        val adapter = ArrayAdapter(
            this,
            androidx.constraintlayout.widget.R.layout.support_simple_spinner_dropdown_item, arrExpertise
        )
        adapter.setDropDownViewResource(com.google.android.material.R.layout.support_simple_spinner_dropdown_item)
        spinnerJInputCategory.adapter = adapter


        //End of Spinner

        //et
        etPerusahaan = findViewById(R.id.etPerusahaan)
        etPosisi = findViewById(R.id.etPosisi)
        etLokasi = findViewById(R.id.etLokasi)
        etGaji = findViewById(R.id.etGaji)
        etDeskripsi = findViewById(R.id.etDeskripsi)
        etMinQ = findViewById(R.id.etMinQ)

        val btnJobSubmit = findViewById<Button>(R.id.btnJobSubmit)
        btnJobSubmit.setOnClickListener{
            val perusahaan = etPerusahaan.text.toString()
            val posisi = etPosisi.text.toString()
            val lokasi = etLokasi.text.toString()
            val gaji = etGaji.text.toString()
            val deskripsi = etDeskripsi.text.toString()
            val minQ = etMinQ.text.toString()
            val kategori = spinnerJInputCategory.selectedItem.toString()

            val job = Job("", perusahaan, lokasi, posisi, imgUrl, gaji, deskripsi, minQ, kategori)
            addToDb(job)
//            startActivity(Intent(applicationContext, JobDetailInput::class.java))
        }
    }

    private fun clearFields(){
        etPerusahaan.setText("")
        etPosisi.setText("")
        etLokasi.setText("")
        etGaji.setText("")
        etDeskripsi.setText("")
        etMinQ.setText("")
        imgUrl = ""
        ivJobLogo.setImageURI(imgUrl.toUri())
    }

    private fun addToDb(job : Job){
        db.collection("tbJob").add(job)
            .addOnSuccessListener { documentReference ->
                Log.d(TAG, "DocumentSnapshot added with ID: ${documentReference.id}")
                documentReference.update("id", documentReference.id)
                clearFields()
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "Error adding document", e)
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode== RESULT_OK) {
            imgUrl = data?.data.toString()
            ivJobLogo.setImageURI(imgUrl.toUri())
            Toast.makeText(applicationContext, imgUrl, Toast.LENGTH_LONG).show()
        }
    }
}