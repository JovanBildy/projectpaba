package com.example.pabaproject

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Logout : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.logout)

        //email
        val email = intent.getStringExtra("email").toString()

        val yes = findViewById<Button>(R.id.button2)
        yes.setOnClickListener {
            startActivity(
                Intent(applicationContext, MainActivity::class.java)
            )
        }

        val no = findViewById<Button>(R.id.button)
        no.setOnClickListener {
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }
    }
}