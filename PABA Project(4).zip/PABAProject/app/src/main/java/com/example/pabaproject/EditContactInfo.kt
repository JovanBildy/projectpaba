package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class EditContactInfo : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var etLokasi : EditText
    private lateinit var etNoHp : EditText
    private lateinit var etEmail : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_contact_info)

        db = FirebaseFirestore.getInstance()

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.ivCInfoBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }


        etLokasi = findViewById(R.id.etEditCInfoLokasi)
        etNoHp = findViewById(R.id.etEditCInfoNoHp)
        etEmail = findViewById(R.id.etEditCInfoEmail)


        //filling informations
        updateInfo(email)


        //save
        val btnSave = findViewById<Button>(R.id.btnEditCInfoSave)
        btnSave.setOnClickListener {
            val collection = db.collection("tbProfileDetail")
            val query = collection.whereEqualTo("email", email)
            query.get()
                .addOnSuccessListener { documents ->
                    if (documents.size() > 0) {
                        val document = documents.first()
                        val documentReference = document.reference

                        documentReference.update("lokasi", etLokasi.text.toString())
                        documentReference.update("noHp", etNoHp.text.toString())
                        documentReference.update("email", etEmail.text.toString())
                    }
                    Toast.makeText(applicationContext, "Change Saved!", Toast.LENGTH_LONG).show()
                    updateInfo(email)
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                }
        }
    }

    private fun updateInfo(email : String) {
        val collection = db.collection("tbProfileDetail")
        val query = collection.whereEqualTo("email", email)
        query.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    etLokasi.hint = document.data["lokasi"].toString()
                    etLokasi.setText(document.data["lokasi"].toString())
                    etNoHp.hint = document.data["noHp"].toString()
                    etNoHp.setText(document.data["noHp"].toString())
                    etEmail.hint = document.data["email"].toString()
                    etEmail.setText(document.data["email"].toString())
                }
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Error getting documents: ", exception)
            }
    }
}