package com.example.pabaproject

data class ProfileDetail(
    var Email: String,
    var FullName: String,
    var NickName: String,
    var Birthdate : String,
    var Gender: String,
    var ProfilePicUrl: String,
    var CurrentPosition: String,
    var Lokasi: String,
    var NoHp : String,
    var Summary: String,
    var ExpectedSalary: String,
)
