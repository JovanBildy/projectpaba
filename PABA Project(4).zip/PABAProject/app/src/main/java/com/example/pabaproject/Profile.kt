package com.example.pabaproject

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.google.firebase.firestore.FirebaseFirestore

class Profile : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var ivProfilePict : ImageView
    private lateinit var ivEditProfile : ImageView
    private lateinit var ivEditContactInfo : ImageView
    private lateinit var ivEditSummary : ImageView
    private lateinit var ivEditSkills : ImageView
    private lateinit var ivEditSalary : ImageView
    private lateinit var tvNama  : TextView
    private lateinit var tvCurPos : TextView
    private lateinit var tvLokasi : TextView
    private lateinit var tvNoHp : TextView
    private lateinit var tvEmail : TextView
    private lateinit var tvSummary : TextView
    private lateinit var tvExpSalary : TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        db = FirebaseFirestore.getInstance()

        ivEditProfile = findViewById(R.id.ivEditProfile)
        ivEditContactInfo = findViewById(R.id.ivEditContactInfo)
        ivEditSummary = findViewById(R.id.ivEditSummary)
        ivEditSkills = findViewById(R.id.ivEditSkills)
        ivEditSalary = findViewById(R.id.ivEditSalary)
        tvNama = findViewById(R.id.tvNama)
        tvCurPos = findViewById(R.id.tvCurPosition)
        tvLokasi = findViewById(R.id.tvProfileLokasi)
        tvNoHp = findViewById(R.id.tvProfileNoHp)
        tvEmail = findViewById(R.id.tvProfileEmail)
        tvSummary = findViewById(R.id.tvProfileSummary)
        tvExpSalary = findViewById(R.id.tvProfileSalary)

        //email
        val email = intent.getStringExtra("email").toString()
        tvEmail.text = email


        //filling informations
        val db = FirebaseFirestore.getInstance()
        val collection = db.collection("tbProfileDetail")
        val query = collection.whereEqualTo("email", email)
        query.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    try {
                        ivProfilePict.setImageURI(document.data["profilePicUrl"].toString().toUri())
                    }
                    catch (ex:Exception)
                    {
                        ex.printStackTrace()
                    }

                    tvNama.text = document.data["fullName"].toString()
                    tvCurPos.text = document.data["currentPosition"].toString()
                    tvLokasi.text = document.data["lokasi"].toString()
                    tvNoHp.text = document.data["noHp"].toString()
                    tvSummary.text = document.data["summary"].toString()
                    tvExpSalary.text = document.data["expectedSalary"].toString()
                }
            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents: ", exception)
            }

        //edit btn
        ivEditProfile.setOnClickListener{
            startActivity(
                Intent(applicationContext, EditProfile::class.java)
                    .putExtra("email", email)
            )
        }

        ivEditContactInfo.setOnClickListener{
            startActivity(
                Intent(applicationContext, EditContactInfo::class.java)
                    .putExtra("email", email)
            )
        }

        ivEditSummary.setOnClickListener {
            startActivity(
                Intent(applicationContext, EditSummary::class.java)
                    .putExtra("email", email)
            )
        }

        ivEditSkills.setOnClickListener {
            startActivity(
                Intent(applicationContext, EditSkill::class.java)
                    .putExtra("email", email)
            )
        }

        ivEditSalary.setOnClickListener{
            startActivity(
                Intent(applicationContext, EditSalary::class.java)
                    .putExtra("email", email)
            )
        }

        //logout
        val logout = findViewById<ImageView>(R.id.ivLogout)
        logout.setOnClickListener {
            startActivity(
                Intent(applicationContext, Logout::class.java)
            )
        }

    }
}