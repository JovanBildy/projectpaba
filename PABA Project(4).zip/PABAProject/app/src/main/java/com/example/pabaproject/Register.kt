package com.example.pabaproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.firestore.FirebaseFirestore
import android.content.Intent
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Register : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private lateinit var  etRegistEmail : EditText
    private lateinit var  etRegistPassword : EditText
    private lateinit var  etRegistPassword2 : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        db = FirebaseFirestore.getInstance()
        etRegistEmail = findViewById(R.id.etRegistEmail)
        etRegistPassword = findViewById(R.id.etRegistPassword)
        etRegistPassword2 = findViewById(R.id.etRegistPassword2)
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        val tvGoToLogin = findViewById<TextView>(R.id.tvGoToLogin)

        btnRegister.setOnClickListener{
            val email = etRegistEmail.text.toString()
            val password = etRegistPassword.text.toString()
            val confPass = etRegistPassword2.text.toString()

            if(email != "" && password != "") {
                if (password == confPass)
                    addUser(db, email, password, confPass)
                else
                    Toast.makeText(applicationContext, "confirmation password berbeda", Toast.LENGTH_LONG).show()
            }
        }

        tvGoToLogin.setOnClickListener{
            goToLoginPage()
        }
    }

    private fun goToLoginPage() {
        startActivity(Intent(applicationContext, MainActivity::class.java))
    }

    private fun addUser(db: FirebaseFirestore, email: String, password: String, confPass: String) {
        val userBaru = User(email, password, confPass)
        db.collection("tbUser").document(email)
            .set(userBaru)
            .addOnSuccessListener {
                etRegistEmail.setText("")
                etRegistPassword.setText("")
                Log.d("Firebase", "Simpan data berhasil!")
                Toast.makeText(applicationContext, "Registered Successfully", Toast.LENGTH_LONG).show()
                goToLoginPage()
            }
            .addOnFailureListener {
                Log.d("Firebase", it.message.toString())
                Toast.makeText(applicationContext, it.message.toString(), Toast.LENGTH_LONG).show()
            }
    }
}