package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.core.net.toUri
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class EditProfile : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var ivProfilePict : ImageView
    private lateinit var etFullName : EditText
    private lateinit var etNickName : EditText
    private lateinit var etCurPos : EditText

    private lateinit var imgUrl: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        db = FirebaseFirestore.getInstance()

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.btnEditProfileBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }


        ivProfilePict = findViewById(R.id.ivEditProfileProfilePict)
        etFullName = findViewById(R.id.etEditProfileFullName)
        etNickName = findViewById(R.id.etEditProfileNickName)
        etCurPos = findViewById(R.id.etEditProfileCurPos)


        //filling informations

        updateInfo(email)

        //editPict
        imgUrl = ""
        val ivEditProfilePict = findViewById<ImageView>(R.id.ivEditProfileEditProfilePict)
        ivEditProfilePict.setOnClickListener {
            val iGallery = Intent(Intent.ACTION_PICK)
            iGallery.data = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            startActivityForResult(iGallery, 1000)
        }


        //save
        val btnSave = findViewById<Button>(R.id.btnEditProfileSave)
        btnSave.setOnClickListener {
            val collection = db.collection("tbProfileDetail")
            val query = collection.whereEqualTo("email", email)
            query.get()
                .addOnSuccessListener { documents ->
                    if (documents.size() > 0) {
                        val document = documents.first()
                        val documentReference = document.reference

                        documentReference.update("profilePicUrl", imgUrl)
                        documentReference.update("fullName", etFullName.text.toString())
                        documentReference.update("nickName", etNickName.text.toString())
                        documentReference.update("currentPosition", etCurPos.text.toString())
                    }
                    Toast.makeText(applicationContext, "Change Saved!", Toast.LENGTH_LONG).show()
                    updateInfo(email)
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                }
        }
    }

    private fun updateInfo(email : String) {
        val collection = db.collection("tbProfileDetail")  // "items" is the name of the collection in the database
        val query = collection.whereEqualTo("email", email)  // Filter the results by the "name" field
        query.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    //error pict
                    ivProfilePict.setImageURI(document.data["profilePicUrl"].toString().toUri())
                    etFullName.hint = document.data["fullName"].toString()
                    etFullName.setText(document.data["fullName"].toString())
                    etNickName.hint = document.data["nickName"].toString()
                    etNickName.setText(document.data["nickName"].toString())
                    etCurPos.hint = document.data["currentPosition"].toString()
                    etCurPos.setText(document.data["currentPosition"].toString())

                }
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Error getting documents: ", exception)
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode== RESULT_OK) {
            imgUrl = data?.data.toString()
            ivProfilePict.setImageURI(imgUrl.toUri())
            Toast.makeText(applicationContext, imgUrl, Toast.LENGTH_LONG).show()
        }
    }
}