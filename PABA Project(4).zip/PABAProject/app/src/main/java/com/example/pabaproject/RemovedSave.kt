package com.example.pabaproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RemovedSave : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remove_saved)
    }
}