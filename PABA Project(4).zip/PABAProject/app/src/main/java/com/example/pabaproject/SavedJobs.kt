package com.example.pabaproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class SavedJobs : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private var arSavedJob = arrayListOf<Job>()
    private lateinit var rvSaved : RecyclerView
    private lateinit var email :String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved_jobs)

        //email
        email = intent.getStringExtra("email").toString()

        val navbarHome = findViewById<ImageView>(R.id.imageView13)
        navbarHome.setOnClickListener {
            startActivity(
                Intent(
                    applicationContext, Home::class.java)
                    .putExtra("email", email)
            )
        }

        db = FirebaseFirestore.getInstance()
        rvSaved = findViewById(R.id.rvSaved)
        buildSaved()

    }

    private fun showSaved(){
        val adapterSaved = AdapterJobCard(arSavedJob)

        rvSaved.layoutManager = LinearLayoutManager(this)
        rvSaved.adapter = adapterSaved

        adapterSaved.setOnItemClickCallback(object : AdapterJobCard.OnItemClickCallback {
            override fun onItemClicked(job: Job) {
                val intent = Intent(applicationContext, JobDetail::class.java)
                intent.putExtra("idJob", job.Id)
                intent.putExtra("email", email)
                startActivity(intent)
            }

            override fun delData(pos: Int) {
            }
        })
    }

    private fun buildSaved(){
        arSavedJob.clear()

        db.collection("tbSaved").whereEqualTo("email", email).get()
            .addOnSuccessListener { saves ->
                for (save in saves) {
                    db.collection("tbJob").whereEqualTo("id", save["idJob"].toString()).get()
                        .addOnSuccessListener { jobs ->
                            for (document in jobs) {
                                val id = document.data?.get("id").toString()
                                val logo = document.data?.get("logo").toString()
                                val posisi = document.data?.get("posisi").toString()
                                val perusahaan = document.data?.get("perusahaan").toString()
                                val lokasi = document.data?.get("lokasi").toString()
                                val gaji = document.data?.get("gaji").toString()
                                val deskripsi = document.data?.get("deskripsi").toString()
                                val minQ = document.data?.get("minimumQualification").toString()
                                val kategori = document.data?.get("kategori").toString()

                                val job = Job(
                                    id,
                                    perusahaan,
                                    lokasi,
                                    posisi,
                                    logo,
                                    gaji,
                                    deskripsi,
                                    minQ,
                                    kategori
                                )
                                arSavedJob.add(job)

                            }
                            showSaved()
                        }
                }
            }
    }
}