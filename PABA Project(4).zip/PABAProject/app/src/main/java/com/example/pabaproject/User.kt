package com.example.pabaproject

data class User(
    var Email: String,
    var Password: String,
    var ConfirmationPass: String,
)
