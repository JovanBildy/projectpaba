package com.example.pabaproject

data class Job(
    var Id: String,
    var Perusahaan: String,
    var Lokasi: String,
    var Posisi: String,
    var Logo: String,
    var Gaji: String,
    var Deskripsi: String,
    var MinimumQualification: String,
    var Kategori: String
)
