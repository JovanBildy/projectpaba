package com.example.pabaproject

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CountrySelection : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_country_selection)

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.btnCountrySelectBack)
        btnBack.setOnClickListener{
            startActivity(Intent(applicationContext, MainActivity::class.java))
        }

        //radio group
        val radioGroup = findViewById<RadioGroup>(R.id.rgCountrySelection)
        val btnNext = findViewById<Button>(R.id.btnCountrySelectNext)

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val radio: RadioButton = findViewById(checkedId)
            val checked = " ${radio.text}"

            Toast.makeText(
                applicationContext, " On checked change :" +
                        checked, Toast.LENGTH_SHORT
            ).show()
        }

        btnNext.setOnClickListener{
            startActivity(
                Intent(applicationContext, RoleSelection::class.java)
                    .putExtra("email", email)
            )
        }
    }
}