package com.example.pabaproject

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class RoleSelection : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role_selection)

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.btnRoleSelectBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, CountrySelection::class.java)
                    .putExtra("email", email)
            )
        }

        val radioGroup = findViewById<RadioGroup>(R.id.rgRoleSelection)
        val btnNext = findViewById<Button>(R.id.btnRoleSelectNext)
        var role = ""

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val radio: RadioButton = findViewById(checkedId)
            role = "${radio.text}"

            Toast.makeText(
                applicationContext, " On checked change :" +
                        role, Toast.LENGTH_SHORT
            ).show()
        }

        btnNext.setOnClickListener{
            if (role == "Find A Job") {
                startActivity(
                    Intent(applicationContext, ProfileDetailForm::class.java)
                        .putExtra("email", email)
                )
            }
            else
                startActivity(
                    Intent(applicationContext, JobInput::class.java)
                        .putExtra("email", email)
                )

        }
    }
}