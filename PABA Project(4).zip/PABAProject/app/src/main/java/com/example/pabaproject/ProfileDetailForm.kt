package com.example.pabaproject

import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.icu.util.Calendar
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

@Suppress("DEPRECATION")
class ProfileDetailForm : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private lateinit var  tvPDFormEmail : TextView
    private lateinit var  etPDFormFullname : EditText
    private lateinit var  etPDFormNickname : EditText
    private lateinit var  spinnerPDFormGender : Spinner
    private lateinit var imgGallery : ImageView
    private lateinit var imgUrl : String
    private val galleryReqCode = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_detail_form)

        db = FirebaseFirestore.getInstance()

        //tv email
        tvPDFormEmail = findViewById(R.id.tvPDFormEmail)
        val email = intent.getStringExtra("email").toString()
        tvPDFormEmail.text = email

        //back
        val btnBack = findViewById<ImageView>(R.id.btnPDFormBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, RoleSelection::class.java)
                    .putExtra("email", email)
            )
        }

        //name
        etPDFormFullname = findViewById(R.id.etPDFormFullName)
        etPDFormNickname = findViewById(R.id.etPDFormNickName)

        //imageview
        imgGallery = findViewById(R.id.imgGallery)
        val ivEditProfilePic = findViewById<ImageView>(R.id.ivPDFormEditProfilePic)
        imgUrl = ""

        ivEditProfilePic.setOnClickListener{
            val iGallery = Intent(Intent.ACTION_PICK)
            iGallery.data = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            startActivityForResult(iGallery, galleryReqCode)
        }
        //end of img view

        //spinner
        spinnerPDFormGender = findViewById(R.id.spinnerPDFormGender)
        val arrGender = arrayOf(
            "Male", "Female"
        )

        val adapter = ArrayAdapter(
            this,
            androidx.constraintlayout.widget.R.layout.support_simple_spinner_dropdown_item, arrGender
        )
        adapter.setDropDownViewResource(com.google.android.material.R.layout.support_simple_spinner_dropdown_item)
        spinnerPDFormGender.adapter = adapter


        //End of Spinner

        //datepicker
        val datePicker = findViewById<DatePicker>(R.id.dpPDForm)

        //save
        val btnSave = findViewById<Button>(R.id.btnPDFormSave)
        btnSave.setOnClickListener{
            //name handle
            val fullName = etPDFormFullname.text.toString()
            val nickName = etPDFormNickname.text.toString()

            //date handle
            val year = datePicker.year
            val month = datePicker.month
            val day = datePicker.dayOfMonth
            val calendar = Calendar.getInstance()
            calendar.set(year, month, day)
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val birthdate = dateFormat.format(calendar.time)

            //spinner handle
            val gender = spinnerPDFormGender.selectedItem.toString()


            val profileDetail = ProfileDetail(
                email,
                fullName,
                nickName,
                birthdate,
                gender,
                imgUrl,
                "-",
                "-",
                "-",
                "-",
                "-"
            )
            addToDb(profileDetail)
        }

        //next
        val btnNext = findViewById<Button>(R.id.btnPDFormNext)
        btnNext.setOnClickListener{
            startActivity(
                Intent(applicationContext, Expertise::class.java)
                    .putExtra("email", email)
            )
        }
    }

    private fun addToDb(profileDetail : ProfileDetail){
        db.collection("tbProfileDetail").document(profileDetail.Email)
            .set(profileDetail)
            .addOnSuccessListener {
                etPDFormNickname.setText("")
                etPDFormFullname.setText("")
                Log.d("Firebase", "Simpan data berhasil!")
                Toast.makeText(applicationContext, "Registered Successfully", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener {
                Log.d("Firebase", it.message.toString())
                Toast.makeText(applicationContext, it.message.toString(), Toast.LENGTH_LONG).show()
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode== RESULT_OK) {
            imgUrl = data?.data.toString()
            imgGallery.setImageURI(imgUrl.toUri())
            Toast.makeText(applicationContext, imgUrl, Toast.LENGTH_LONG).show()
        }
    }
}