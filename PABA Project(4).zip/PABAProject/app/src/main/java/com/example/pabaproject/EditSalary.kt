package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class EditSalary : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var etMin : EditText
    private lateinit var etMax : EditText
    private lateinit var etCurrency : EditText
    private lateinit var etFreq : EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_salary)

        db = FirebaseFirestore.getInstance()

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.ivEditSalBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }


        etMin = findViewById(R.id.etEditSalMin)
        etMax = findViewById(R.id.etEditSalMax)
        etCurrency = findViewById(R.id.etEditSalCurrency)
        etFreq = findViewById(R.id.etEditSalFreq)

        clearFields()

        //save
        val btnSave = findViewById<Button>(R.id.btnEditSalSave)
        btnSave.setOnClickListener {
            val min = etMin.text.toString()
            val max = etMax.text.toString()
            val currency = etCurrency.text.toString()
            val freq = etFreq.text.toString()
            val salary = "$min - $max $currency $freq"

            val collection = db.collection("tbProfileDetail")
            val query = collection.whereEqualTo("email", email)
            query.get()
                .addOnSuccessListener { documents ->
                    if (documents.size() > 0) {
                        val document = documents.first()
                        val documentReference = document.reference

                        documentReference.update("expectedSalary", salary)
                    }
                    Toast.makeText(applicationContext, "Change Saved!", Toast.LENGTH_LONG).show()
                    clearFields()
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                }
        }
    }

    private fun clearFields() {
        etMin.setText("")
        etMax.setText("")
        etCurrency.setText("")
        etFreq.setText("")
    }
}