package com.example.pabaproject

data class Skill(
    var Email: String,
    var Skill: String
)
