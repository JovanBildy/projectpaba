package com.example.pabaproject

data class SavedDetail(
    var Email: String,
    var idJob: String,
)
