package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.core.net.toUri
import com.google.firebase.firestore.FirebaseFirestore
import java.lang.Exception

@Suppress("DEPRECATION")
class JobDetail : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore

    private lateinit var ivLogo : ImageView
    private lateinit var tvPosisi : TextView
    private lateinit var tvPerusahaan : TextView
    private lateinit var tvLokasi : TextView
    private lateinit var tvGaji : TextView
    private lateinit var tvDeskripsi : TextView


    private lateinit var imgUrl: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_detail)

        db = FirebaseFirestore.getInstance()

        //email
        val email = intent.getStringExtra("email").toString()

        //get idJob intent
        val idJob = intent.getStringExtra("idJob").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.ivJobDetailBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Home::class.java)
                    .putExtra("email", email)
            )
        }

        ivLogo = findViewById(R.id.ivJobDetailLogo)
        tvPosisi = findViewById(R.id.tvJobDetailPosisi)
        tvPerusahaan = findViewById(R.id.tvJobDetailPerusahaan)
        tvLokasi = findViewById(R.id.tvJobDetailLokasi)
        tvGaji = findViewById(R.id.tvJobDetailGaji)
        tvDeskripsi = findViewById(R.id.tvJobDetailDeskripsi)

        //filling informations
        getDetail(idJob)

        val ivSave = findViewById<ImageView>(R.id.ivJobDetailSave)
        ivSave.setOnClickListener {
            db.collection("tbSaved").add(
                SavedDetail(email, idJob)
            )
            Toast.makeText(applicationContext, "Saved Successfully", Toast.LENGTH_LONG).show()
        }
    }

    private fun getDetail(idJob : String) {
        val collection = db.collection("tbJob")
        val query = collection.document(idJob)
        query.get()
            .addOnSuccessListener { document ->
                //error pict
//                try {
//                    ivLogo.setImageURI(document.data?.get("logo").toString().toUri())
//                }
//                catch (Ex : Exception){}

                tvPosisi.setText(document.data?.get("posisi").toString())
                tvPerusahaan.setText(document.data?.get("perusahaan").toString())
                tvLokasi.setText(document.data?.get("lokasi").toString())
                tvGaji.setText(document.data?.get("gaji").toString())
                tvDeskripsi.setText(document.data?.get("deskripsi").toString())
            }
            .addOnFailureListener { exception ->
                Log.w(ContentValues.TAG, "Error getting documents: ", exception)
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode== RESULT_OK) {
            imgUrl = data?.data.toString()
            ivLogo.setImageURI(imgUrl.toUri())
            Toast.makeText(applicationContext, imgUrl, Toast.LENGTH_LONG).show()
        }
    }
}