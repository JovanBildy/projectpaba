package com.example.pabaproject

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class Expertise : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private lateinit var  cbExpertise1 : CheckBox
    private lateinit var  cbExpertise2 : CheckBox
    private lateinit var  cbExpertise3 : CheckBox
    private lateinit var  cbExpertise4 : CheckBox
    private lateinit var  cbExpertise5 : CheckBox
    private lateinit var  cbExpertise6 : CheckBox
    private lateinit var  cbExpertise7 : CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expertise)

        db = FirebaseFirestore.getInstance()

        //get email intent
        val email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.btnExpertiseBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, ProfileDetailForm::class.java)
                    .putExtra("email", email)
            )
        }

        //checkbox
        cbExpertise1 = findViewById(R.id.checkBox)
        cbExpertise2 = findViewById(R.id.checkBox1)
        cbExpertise3 = findViewById(R.id.checkBox2)
        cbExpertise4 = findViewById(R.id.checkBox3)
        cbExpertise5 = findViewById(R.id.checkBox4)
        cbExpertise6 = findViewById(R.id.checkBox5)
        cbExpertise7 = findViewById(R.id.checkBox6)
        val checkBoxes = listOf(
            cbExpertise1,
            cbExpertise2,
            cbExpertise3,
            cbExpertise4,
            cbExpertise5,
            cbExpertise6,
            cbExpertise7,
        )


        //next
        val btnNext = findViewById<Button>(R.id.btnExpertiseNext)
        btnNext.setOnClickListener{
            checkBoxes.forEach { checkBox ->
                if (checkBox.isChecked) {
                    val skill = Skill(email, checkBox.text.toString())
                    db.collection("tbSkill").add(skill).addOnFailureListener {
                        Log.d("TB Skill", "Gagal")
                    }
                }
            }

            startActivity(
                Intent(applicationContext, Home::class.java)
                    .putExtra("email", email)
            )
        }
    }


}