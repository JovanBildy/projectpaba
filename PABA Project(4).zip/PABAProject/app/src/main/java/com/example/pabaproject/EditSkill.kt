package com.example.pabaproject

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

@Suppress("DEPRECATION")
class EditSkill : AppCompatActivity() {

    private lateinit var db : FirebaseFirestore
    private lateinit var  spinnerEditSkill : Spinner
    private var arrSkill = arrayListOf<Skill>()
    private lateinit var rvSkill : RecyclerView
    private lateinit var email :String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_skill)

        db = FirebaseFirestore.getInstance()

        //get email intent
        email = intent.getStringExtra("email").toString()

        //back
        val btnBack = findViewById<ImageView>(R.id.ivEditSkillBack)
        btnBack.setOnClickListener{
            startActivity(
                Intent(applicationContext, Profile::class.java)
                    .putExtra("email", email)
            )
        }

        //spinner
        spinnerEditSkill = findViewById(R.id.spinnerEditSkillSkills)
        val arrSkill = arrayOf(
            "Accounting and Finance", "Architecture and Engineering", "Information Technology and Software",
            "Management and Consultancy", "Media, Design, and Creatives", "Sales and Marketing",
            "Writing and Content"
        )

        val adapter = ArrayAdapter(
            this,
            androidx.constraintlayout.widget.R.layout.support_simple_spinner_dropdown_item, arrSkill
        )
        adapter.setDropDownViewResource(com.google.android.material.R.layout.support_simple_spinner_dropdown_item)
        spinnerEditSkill.adapter = adapter
        //End of Spinner



        rvSkill = findViewById(R.id.rvEditSkillItem)
        importSkill()

        //save
        val btnSave = findViewById<Button>(R.id.btnEditSkillSave)


        btnSave.setOnClickListener {
            val collection = db.collection("tbSkill")
            val selected = spinnerEditSkill.selectedItem.toString()

            val query = collection.whereEqualTo("email", email).whereEqualTo("skill", selected)
            query.get()
                .addOnSuccessListener { documents ->
                    if (documents.size() == 0) {
                        collection.add(Skill(email, selected))
                        Toast.makeText(applicationContext, "Change Saved!", Toast.LENGTH_LONG)
                            .show()
                        startActivity(
                            Intent(applicationContext, EditSkill::class.java)
                                .putExtra(
                                    "email", email
                                )
                        )
                    }
                }
                .addOnFailureListener { exception ->
                    Log.w(ContentValues.TAG, "Error getting documents: ", exception)
                }
        }
    }

    private fun showSkill(){
        val adapterSkill = AdapterSkill(arrSkill)

        rvSkill.layoutManager = LinearLayoutManager(this)
        rvSkill.adapter = adapterSkill

        adapterSkill.setOnItemClickCallback(object : AdapterSkill.OnItemClickCallback {
            override fun onItemClicked(data: Skill) {
                db.collection("tbSkill").whereEqualTo("email", email).whereEqualTo("skill", data.Skill).get()
                    .addOnSuccessListener {
                        skills ->
                        for (skill in skills){
                            skill.reference.delete()
                            Toast.makeText(applicationContext, "Deleted!", Toast.LENGTH_LONG).show()
                            startActivity(
                                Intent(applicationContext, EditSkill::class.java)
                                    .putExtra("email", email
                                    )
                            )
                        }
                    }
            }
            override fun delData(pos: Int) {
            }
        })
    }

    private fun importSkill(){
        arrSkill.clear()

        db.collection("tbSkill").whereEqualTo("email", email).get()
            .addOnSuccessListener { skills ->
                for (item in skills) {
                    val skill = item.data["skill"].toString()
                    arrSkill.add(Skill(email, skill))
                showSkill()
            }
        }
    }
}